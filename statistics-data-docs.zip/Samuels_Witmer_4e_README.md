# Samuels_Witmer_4e datasets

This folder contains datasets associated with **Samuels Witmer 4e**.

Use this file to document each dataset in the folder.

## Files

Add a row here for each file in this folder.

| File | Description | Codebook (if separate) |
|------|-------------|------------------------|
| `example.csv` | _Short description_ | `example.md` |

## Notes

- Describe the overall theme of these datasets (e.g. which textbook / chapter they come from).
- If there is a separate solutions manual or exercises referring to these data, mention that here.
